from difraciones import *

#---------------------#
# Importing libraries #
#---------------------#

import matplotlib
matplotlib.use( 'Qt5Agg' )
import matplotlib.pyplot as p

#-----------------#
# Ploting helpers #
#-----------------#

def display_image( fig_n, img, title = "", x_label = "", y_label = "", block = False ):
    p.figure( fig_n )
    p.clf()
    p.imshow( img, extent = [ -D / 2000, D / 2000, -D / 2000, D / 2000 ] )
    p.gray()
    p.title( title )
    p.xlabel( x_label )
    p.ylabel( y_label )
    p.show( block = block )

def plot_data( fig_n, x, y, title = "", x_label = "", y_label = "", block = False ):
    p.figure( fig_n )
    p.clf()
    p.plot( x, y )
    p.title( title )
    p.xlabel( x_label )
    p.ylabel( y_label )
    p.show( block = block )


#--------------------#
# Initial parameters #
#--------------------#

# Basic parameters for calc
M = 2000 # Mesh size in pixels
lamb = 600e-9 # Wavelength [m]


# Observation parameters (already known)
vE = 29800 # Earth translation speed [m/s]
vr = 5000 # Object speed
ang = 0 # Angle to calcule tangencial speed of the object
fps = 20 # Frames per second
mV = 14 # Apparent magnitude of the star
nEst = 34 # Stellar classification
# A0=1; A1=2; A2=3; A3=4; A4=5; A5=6; A7=7; F0=8; F2=9; F3=10; F5=11; F6=12; F7=13; F8=14;
# G0=15; G1=16; G2=17; G5=18; G8=19; K0=20; K1=21; K2=22; K3=23; K4=24; K5=25; K7=26;
# M0=27; M1=28; M2=29; M3=30; M4=31; M5=32; M6=33; M7=34; M8=35;
nLamb = 10 # Number of wavelengths for the spectral calculation (spectra function)


# Occultation event parameters (unknow)
d = 2000 # Object diameter [m]
ua = 40 # Object distance (astronomicl units)
D = calc_plano( d, lamb, ua ) # Plane size / Field of view [m]
toffset = 0 #In pixels
T = 0 # Observation direction, in degrees
b = 0 # Impact parameter [m]
z = 1.496e11 * ua # Object distance [m]


#----------------------#
# Initial calculations #
#----------------------#

# Defining objects
O1 = pupilCO( M, D, d ) # Circular object
O2 = pupil_doble( M, D, d ) # Binary object
I1 = fresnel( O1, M, D, z, lamb ) # Monochrome diffraction pattern (object 1)
I2 = fresnel( O2, M, D, z, lamb ) # Monochrome diffraction pattern (object 2)

# display_image( 0, O1 )
# display_image( 1, I1, block = True )

#-----------------------------------#
# Spectral contribution calculation #
#-----------------------------------#

I1s = spectra( I1, M, D, z, nEst, nLamb ) # Chromatic pattern
tipo, R_star = calc_rstar( mV, nEst, ua ) # Calculate radius and stellar classification (estrellas.dat)


#------------------------------#
# Pattern from extended source #
#------------------------------#

I1f = promedio_PD( I1s, R_star, D, M, d ) #Extended source contribution


#---------------#
# Poisson noise #
#---------------#

snr = SNR_TAOS2( mV ) # Signal-to-noise ratio, according to TAOS-II
I1n = add_ruido( I1f, mV ) # Add noise
#display_image( 0, I1n, block = False )

#-----------------------------#
# Extract diffraction profile #
#-----------------------------#

# T [degrees]
# b [m]
xn, yn = extraer_perfil( I1n, M, D, T, b ) #With noise
#plot_data( 1, xn, yn, title = "Diffraction profile with noise", x_label = "Distance [km]", y_label = "Normalized intensity" )


#----------#
# Sampling #
#----------#

x1, y1, x2, y2 = muestreos( yn, D, vr, fps, toffset, vE, ang, ua )
#plot_data( 2, x2, y2, title = "Sampled diffraction profile with noise", x_label = "Time [s]", y_label = "Normalized intensity", block = True )
#np.savetxt("datos2.txt", np.array([x2,y2]).T, delimiter=",")