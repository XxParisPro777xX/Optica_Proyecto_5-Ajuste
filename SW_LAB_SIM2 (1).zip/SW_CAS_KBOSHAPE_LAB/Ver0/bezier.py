import numpy as np

def curve( t, x, y ):
    xx, yy = 0, 0
    n = len( x ) - 1
    for i in range( 0, n + 1 ):
        xx = xx + combination( i, n ) * ( t ** i ) * ( ( 1 - t ) ** ( n - i ) ) * x[ i ]
        yy = yy + combination( i, n ) * ( t ** i ) * ( ( 1 - t ) ** ( n - i ) ) * y[ i ]
    return xx, yy

def combination( p, n ):
    return factorial( n ) / ( factorial( p ) * factorial( n - p ) )

def factorial( n ):
    result = 1
    for i in range( 1, n + 1 ):
        result = result * i
    return result

def kochanek_bartels_segment( t, tension, continuity, bias, p0x, p0y, p1x, p1y, p2x, p2y, p3x, p3y ):
    P0x = p1x
    P0y = p1y
    P1x = p1x + ( ( 1 - tension ) * ( 1 + bias ) * ( 1 + continuity ) * ( p1x - p0x ) + ( 1 - tension ) * ( 1 - bias ) * ( 1 - continuity ) * ( p2x - p1x ) ) / 6
    P1y = p1y + ( ( 1 - tension ) * ( 1 + bias ) * ( 1 + continuity ) * ( p1y - p0y ) + ( 1 - tension ) * ( 1 - bias ) * ( 1 - continuity ) * ( p2y - p1y ) ) / 6
    P2x = p2x - ( ( 1 - tension ) * ( 1 + bias ) * ( 1 - continuity ) * ( p2x - p1x ) + ( 1 - tension ) * ( 1 - bias ) * ( 1 + continuity ) * ( p3x - p2x ) ) / 6
    P2y = p2y - ( ( 1 - tension ) * ( 1 + bias ) * ( 1 - continuity ) * ( p2y - p1y ) + ( 1 - tension ) * ( 1 - bias ) * ( 1 + continuity ) * ( p3y - p2y ) ) / 6
    P3x = p2x
    P3y = p2y
    return curve( t, [ P0x, P1x, P2x, P3x ], [ P0y, P1y, P2y, P3y ] )

def kochanek_bartels_curve( t, x, y, tension = 0, continuity = 0, bias = 0 ):
    segments = []
    points = []
    for i in range( 0, len( x ) ):
        xx, yy = kochanek_bartels_segment( t, tension, continuity, bias, getElement( x, i - 1 ), getElement( y, i - 1 ), getElement( x, i ), getElement( y, i ), getElement( x, i + 1 ), getElement( y, i + 1 ), getElement( x, i + 2 ), getElement( y, i + 2 ) )
        segments.append( list( zip( xx, yy ) ) )
        for xxx, yyy in zip( xx, yy ):
            points.append( xxx )
            points.append( yyy )
    return segments, points

def getElement( data, i ):
    return data[ i ] if i < len( data ) else data[ i - len( data ) ]