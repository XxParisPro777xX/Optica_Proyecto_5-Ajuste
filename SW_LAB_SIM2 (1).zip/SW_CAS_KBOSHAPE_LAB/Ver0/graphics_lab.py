from tkinter import filedialog as fl
import tkinter as tk
from PIL import Image,ImageTk
import numpy as np
import matplotlib
from matplotlib.backends.backend_tkagg import (NavigationToolbar2Tk)
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import matplotlib.backends.backend_tkagg as tkagg
from matplotlib.figure import Figure
import matplotlib.pyplot as plt
import pandas as pd
matplotlib.use('TkAgg')
import editor_lab
import plots_lab
from tkinter import Frame
from scipy.interpolate import interp1d
from scipy.stats import chisquare


class Aplicacion:

    def __init__(self):
        self.ventana1=tk.Tk()
        self.ventana1.protocol( 'WM_DELETE_WINDOW', self.ventana1.quit )
        self.ventana1.title('SW-CAA-Shapes-LAB')
        #self.ventana1.geometry('1450x800')
        self.ventana1.configure(bg='white')
        self.fullScreenState = False
        self.ventana1.attributes('-fullscreen', True)
        self.ventana1.bind("<F11>",
                         lambda event: self.ventana1.attributes("-fullscreen",
                                    not self.ventana1.attributes("-fullscreen")))
        self.ventana1.bind("<Escape>",
                         lambda event: self.ventana1.attributes("-fullscreen",
                                    False))
        '''self.imagen = self.imagen.resize((250, 250), Image.ANTIALIAS)
        self.imagen = ImageTk.PhotoImage(self.imagen)
        self.image_locate = tk.Button(self.ventana1,image =self.imagen)
        self.image_locate.grid(column=1,row=1,rowspan=2)'''
        #scrollbar=tk.Scrollbar(self.ventana1)
        #scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        self.n_rows =2
        self.n_columns =2
        for i in range(self.n_rows):
            self.ventana1.grid_rowconfigure(i,  weight =1)
        for i in range(self.n_columns):
            self.ventana1.grid_columnconfigure(i,  weight =1)
        #self.canvas1=tk.Canvas(self.ventana1, width=700, height=700, background="white",relief='ridge',borderwidth =5)
        
        self.canvas1=editor_lab.Editor(self.ventana1,canvas_size=400)
        #scrollbar.config(command=self.canvas1.yview)
        self.canvas1.grid(column=0,row=0,rowspan=1)
        e,e2,e3,e4,fs=plots_lab.plot()
        self.f = fs
        self.p = e
        self.linea1c1, = self.p.plot([],[],'r-', color='red', label='Perfil real')
        self.linea2c1, = self.p.plot([],[],'r-', color='blue', label='Perfil muestreo')
        self.p.set_xlabel("Distance [m]",fontdict={'family': 'serif',
                    'color' : 'darkblue',
                    'weight': 'bold',
                    'size': 10})
        self.p.set_ylabel("Flux",fontdict={'family': 'serif',
                    'color' : 'darkblue',
                    'weight': 'bold',
                    'size': 10})
        self.p.set_title("Diffraction profile",
          fontdict={'family': 'serif',
                    'color' : 'darkblue',
                    'weight': 'bold',
                    'size': 12})
        #self.linea3, = self.p.plot([],[],'r-', color='green', label='Perfil principal')
        #self.p.legend()
        self.p2 = e2
        self.linea1c2, = self.p2.plot([],[],'r-', color='red', label='Data')
        self.linea2c2, = self.p2.plot([],[],'r-', color='blue', label='Simulated')
        self.p2.set_xlabel("Time [s]",fontdict={'family': 'serif',
                    'color' : 'darkblue',
                    'weight': 'bold',
                    'size': 10})
        self.p2.set_title("Sampled profile",
          fontdict={'family': 'serif',
                    'color' : 'darkblue',
                    'weight': 'bold',
                    'size': 12})

        #self.f2 = Figure(figsize=(8,4), dpi=100)
        self.c2 = e3
        self.c2.set_xlabel("FOV",fontdict={'family': 'serif',
                    'color' : 'darkblue',
                    'weight': 'bold',
                    'size': 12})
        self.c4 = e4
        self.c4.set_xlabel("Diff Pattern" ,fontdict={'family': 'serif',
                    'color' : 'darkblue',
                    'weight': 'bold',
                    'size': 12})
        #self.p.set_xlabel("Distancia [km]")
      #  self.p.set_ylabel("Flujo")
        #self.style = Style()
       # self.style.configure("BW.TLabel", foreground="black", background="white")
#vsb = tk.Scrollbar(self.ventana1, orient="vertical", command=self.canvas1.yview)
#vsb.grid(row=0, column=1, sticky='ns')
#self.ventana1.configure(yscrollcommand=vsb.set)  
      

        #self.p2.legend()
        self.canvas = FigureCanvasTkAgg(self.f, self.ventana1)
        self.canvas.draw()
        self.canvas.get_tk_widget().grid(row=0,column=1, rowspan=2)



        self.toolbarFrame = Frame(master=self.ventana1)
        self.toolbarFrame.grid(row=2,column=1)
        self.toolbar = NavigationToolbar2Tk(self.canvas, self.toolbarFrame)
        #self.draw_graphic()
        self.prints()
        self.params()
        self.ventana1.mainloop()

    def boton_presion(self, evento):
        self.presionado=True


    def mover_mouse(self, evento):
        if self.presionado:
            self.canvas1.create_oval(evento.x-15,evento.y-15 ,evento.x+15, evento.y+15, width=2, fill='black')

    def boton_soltar(self,evento):
        self.presionado=False

    def action_button(self):
        print("hello!!!!!")

    def new_window(self):
        newWindow = tk.Toplevel(self.ventana1)
        a = tk.Label(newWindow ,text = "Dato 1").grid(row = 0,column = 0)
        b = tk.Label(newWindow ,text = "Dato 2").grid(row = 1,column = 0)
        c = tk.Label(newWindow ,text = "Dato 3").grid(row = 2,column = 0)
        d = tk.Label(newWindow ,text = "Dato 4").grid(row = 3,column = 0)
        a1 = tk.Entry(newWindow).grid(row = 0,column = 1)
        b1 = tk.Entry(newWindow).grid(row = 1,column = 1)
        c1 = tk.Entry(newWindow).grid(row = 2,column = 1)
        d1 = tk.Entry(newWindow).grid(row = 3,column = 1)
        button_modal= tk.Button(newWindow, text="Cargar datos", command=self.cargar_datos,  width=10)
        button_modal.grid(column = 0, row = 4)

    def prints(self):
        self.M2=tk.StringVar()
        self.M2.set(1024)
        self.vE2 = tk.StringVar()
        self.vE2.set(2e-3)
        self.vr2 = tk.StringVar()
        self.vr2.set(0)
        self.ang2 = tk.StringVar()
        self.ang2.set(10e-9)
        self.fps2 = tk.StringVar()
        self.fps2.set(20)
        self.mV2 = tk.StringVar()
        self.mV2.set(14)
        self.nEst2 = tk.StringVar()
        self.nEst2.set(0)
        self.nLamb2 = tk.StringVar()
        self.nLamb2.set(1)
        self.ua2 = tk.StringVar()
        self.ua2.set(2.18)
        self.d2 = tk.StringVar()
        self.d2.set(2e-3)
        self.T2 = tk.StringVar()
        self.T2.set(0)
        self.b2 = tk.StringVar()
        self.b2.set(0)
        self.toffset2 = tk.StringVar()
        self.toffset2.set(0)
        self.cent2 = tk.StringVar()
        self.cent2.set(212)
        self.expt2 = tk.StringVar()
        self.expt2.set(0.05)
        self.lmda2 = tk.StringVar()
        self.lmda2.set(650e-9)
        self.chi2 = tk.StringVar()
        self.chi2.set(999.0)
        self.skiprows2 = tk.StringVar()
        self.skiprows2.set(14)
        
        
    def params(self):
        
        #Window building AREA DE PARAMETROS
        self.my_frame = tk.Frame(self.ventana1,width=400, height=400, bg="cyan")
        self.my_frame.grid(column=0,row=1)
        self.scrollbar = tk.Scrollbar(self.ventana1, orient=tk.HORIZONTAL)
        #scrollbar=tk.Scrollbar(self.ventana1)
        #self.scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        # 2D Calculation parameters 
        self.lab0 = tk.Label(self.my_frame ,text = "2D CALCULATION PARAMETERS!!").grid(row = 0,column = 0)
        self.lab1 = tk.Label(self.my_frame ,text = "Mesh size:").grid(row = 1,column = 0)
        self.M = tk.Entry(self.my_frame,textvariable = self.M2,width=10, fg="black").grid(row = 1,column = 1,padx=5, pady=5)
        self.lab2 = tk.Label(self.my_frame ,text = "Distance [m]:").grid(row = 2,column = 0, padx=1, pady=1)
        self.ua = tk.Entry(self.my_frame,width=10,textvariable = self.ua2).grid(row = 2,column = 1, padx=5, pady=5)
        self.lab3 = tk.Label(self.my_frame ,text = "Object diameter [m]:").grid(row = 3,column = 0, padx=1, pady=1)
        self.d = tk.Entry(self.my_frame,width=10, textvariable = self.d2).grid(row = 3,column = 1, padx=5, pady=5)
        self.lab4 = tk.Label(self.my_frame ,text = "Number of Wavelengths:").grid(row = 4,column = 0, padx=1, pady=1)
        self.nLamb = tk.Entry(self.my_frame,width=10,textvariable = self.nLamb2).grid(row = 4,column = 1, padx=5, pady=5)
        self.lab5 = tk.Label(self.my_frame ,text = "Apparent magnitude:").grid(row = 5,column = 0, padx=1, pady=1)
        self.mV = tk.Entry(self.my_frame,width=10,textvariable = self.mV2).grid(row = 5,column = 1, padx=5, pady=5)
        self.lab6 = tk.Label(self.my_frame ,text = "Source Size [m]:").grid(row = 6,column = 0, padx=1, pady=1)
        self.nEst = tk.Entry(self.my_frame,width=10, textvariable = self.nEst2).grid(row = 6,column = 1, padx=5, pady=5)
        self.lab13 = tk.Label(self.my_frame ,text = "Separation Wlengths [m]:").grid(row = 7,column = 0, padx=1, pady=1)
        self.ang = tk.Entry(self.my_frame,width=10, textvariable = self.ang2).grid(row = 7,column = 1, padx=5, pady=5)
        self.lab18 = tk.Label(self.my_frame ,text = "Wavelength [m]:").grid(row = 8,column = 0, padx=1, pady=1)
        self.lmda = tk.Entry(self.my_frame,width=10, textvariable = self.lmda2).grid(row = 8,column = 1, padx=5, pady=5)
        #1D Calculation parameters
        self.lab17 = tk.Label(self.my_frame ,text = "1D CALCULATION PARAMETERS!!").grid(row = 0,column = 3, padx=1, pady=1)
        self.lab7 = tk.Label(self.my_frame ,text = "Cam translation speed [m/s]:").grid(row = 1,column = 3)
        self.vE = tk.Entry(self.my_frame,width=10,textvariable = self.vE2).grid(row = 1,column = 4, padx=5, pady=5)
        self.lab8 = tk.Label(self.my_frame ,text = "Object speed [m/s]:").grid(row = 2,column = 3, padx=1, pady=1)
        self.vr = tk.Entry(self.my_frame, width=10,textvariable = self.vr2).grid(row = 2,column = 4, padx=5, pady=5)
        self.lab9 = tk.Label(self.my_frame ,text = "Time Offset [s]:").grid(row = 3,column = 3, padx=1, pady=1)
        self.toffset = tk.Entry(self.my_frame,width=10,textvariable = self.toffset2).grid(row = 3,column = 4, padx=5, pady=5)
        self.lab10 = tk.Label(self.my_frame ,text = "Fps   :").grid(row = 4,column = 3, padx=1, pady=1)
        self.fps = tk.Entry(self.my_frame,width=10, textvariable = self.fps2).grid(row = 4,column = 4, padx=5, pady=5)
        self.lab11 = tk.Label(self.my_frame ,text = "Reading Direction [deg]:").grid(row = 5,column = 3, padx=1, pady=1)
        self.T = tk.Entry(self.my_frame,width=10, textvariable = self.T2).grid(row = 5,column = 4, padx=5, pady=5)
        self.lab12 = tk.Label(self.my_frame ,text = "Impact parameter [m]:").grid(row = 6,column = 3, padx=1, pady=1)
        self.b = tk.Entry(self.my_frame,width=10, textvariable = self.b2).grid(row = 6,column = 4, padx=5, pady=5)
        self.lab13 = tk.Label(self.my_frame ,text = "CHi2 :").grid(row = 7,column = 3, padx=1, pady=1)
        self.chi = tk.Entry(self.my_frame,width=15, textvariable = self.chi2,bg='red').grid(row = 7,column = 4, padx=5, pady=5)
        
        #Data Parameters tangra
        self.lab16 = tk.Label(self.my_frame ,text = "TANGRA DATA PARMS!!").grid(row = 9,column = 0, padx=1, pady=1)
        self.lab14 = tk.Label(self.my_frame ,text = "Center of LC:").grid(row = 9,column = 1, padx=1, pady=1)
        self.cent = tk.Entry(self.my_frame,width=10, textvariable = self.cent2).grid(row = 9,column = 2, padx=5, pady=5)
        self.lab15 = tk.Label(self.my_frame ,text = "Exp Time[s]:").grid(row = 9,column = 3, padx=1, pady=1)
        self.expt = tk.Entry(self.my_frame,width=10, textvariable = self.expt2).grid(row = 9,column = 4, padx=5, pady=5)        
        
        #Action Buttons
        self.lab15 = tk.Label(self.my_frame ,text = "SEGUIR ORDEN EN BOTONES").grid(row = 0,column = 5, padx=1, pady=1)
        self.button = tk.Button(self.my_frame, text="2D Calc", command= self.get_pattern,  width=10)
        self.button.grid(column=5,row=1, rowspan=2, padx=5, pady=10)
        self.button = tk.Button(self.my_frame, text="Load CSV", command=self.cargar_datos,  width=10)
        self.button.grid(column=5,row=3, rowspan=2, padx=5, pady=10)
        self.skiprows = tk.Entry(self.my_frame,width=7, textvariable = self.skiprows2,bg='green').grid(row = 5,column = 5, padx=5, pady=5)
        self.button = tk.Button(self.my_frame, text="1D Calc", command= self.get_curves,  width=10)
        self.button.grid(column=5,row=6, rowspan=2, padx=5, pady=10)
        self.button = tk.Button(self.my_frame, text="Reset", command=self.canvas1.create_poly,  width=10)
        self.button.grid(column=5,row=8, rowspan=2, padx=5, pady=10)

    def get_pattern(self):  #process_image( self, M, mV, nEst, nLamb, d, ua,lmda,ang)2D GRAPH
        global img,I1f,D
        img,I1f,D =self.canvas1.process_image(M = int(self.M2.get()), mV=float(self.mV2.get()), nEst=float(self.nEst2.get()), nLamb=int(self.nLamb2.get()), d=float(self.d2.get()), ua=float(self.ua2.get()),lmda=float(self.lmda2.get()), ang =float(self.ang2.get()))
        #self.draw_graphic(x,y,x1,y1,False)
        self.draw_image(img,I1f,D,b =float(self.b2.get()),T=float(self.T2.get()) )

    def get_curves(self): # process_curves( self, I1f, D, M, vE, vr, fps, mV, ua, toffset, T, b) 1D GRAPHS
        global img,I1f,D,x,y,x1,y1,secs,normflx
        try:  
            assert len(img)
        except AssertionError:  
            print ("Try Calcutating 2D pattern FIRST!!")
        else:  
            print ("Reading 2D Pattern")
            x,y,x1,y1 =self.canvas1.process_curves(I1f,D,M = int(self.M2.get()), vE = float(self.vE2.get()), vr= float(self.vr2.get()), fps=float(self.fps2.get()), mV=float(self.mV2.get()), ua=float(self.ua2.get()), toffset=float(self.toffset2.get()), T=float(self.T2.get()), b =float(self.b2.get()))
            self.draw_graphic(x,y,x1,y1,False)
            #self.draw_image(img,I1f,D)
            try:
                assert len(secs)
            except AssertionError:
                print('Warning: Cant calculate ChiSquare, please open DATAFILE')
            else:
                fun=interp1d(x1,y1)
                sim=fun(secs)
                print(chisquare(sim,normflx))
            

    def draw_graphic(self,x,y,x1,y1,band): #gRAFICAS 1D
        global D
        global secs,normflx
        if band:
           self.linea1c1.set_data( x,y)
           self.linea1c2.set_data( x1,y1)
        else:
            self.linea2c1.set_data(x,y)
            self.linea2c2.set_data(x1,y1)
        
        func=interp1d(secs,normflx)
        try:  
            assert max(x1)>max(secs)
        except AssertionError:  
            print ("Simulation Range is larger than DATA!!")
        else:
            sim=func(x1)
            self.chi2.set(chisquare(nT,sim))
        
        #dIBUJAR LINEAS DE PARAMETRO DE IMPACTO
        M = int(self.M2.get())
        m2p=M/D
        x=np.linspace(-D/2,D/2,M)
        T=float(self.T2.get()); b =float(self.b2.get())
        #calcular los arreglos de coordenada X a extraer
        x1=x*np.cos(T*np.pi/180)-b*np.sin(T*np.pi/180)
        x2=x*np.sin(T*np.pi/180)+b*np.cos(T*np.pi/180)
        self.c4.plot(x1,x2)
        self.c2.plot(x1,x2)
        self.p2.relim()
        self.p2.autoscale_view()
        self.p.relim()
        self.p.autoscale_view()
        self.f.canvas.draw()
        #print('creado 1')
        #np.savetxt("datos2.txt", np.array([x,y]).T, delimiter=",")
        #print('creado')
        
    def draw_image(self, img,I1f, D,b,T ): # GRAFICAS 2D
        #M=len(img)
        #m2p=M/D
        #x=np.linspace(-D/2,D/2,M)
        #calcular los arreglos de coordenada X a extraer
        #x1=x*np.cos(T*np.pi/180)-b*np.sin(T*np.pi/180)
        #x2=x*np.sin(T*np.pi/180)+b*np.cos(T*np.pi/180)
        
        self.c4.imshow( I1f,extent = [ -D / 2, D / 2, -D / 2, D / 2 ], cmap=plt.cm.gray)
        #self.c4.plot(x1,x2)
        self.c2.imshow( img,extent = [ -D / 2, D / 2, -D / 2, D / 2 ], cmap=plt.cm.gray)
        #self.c2.plot(x1,x2)
        self.f.canvas.draw()

    #Read File CSV from TANGRA


    def cargar_datos(self):
        global secs,normflx
        file = fl.askopenfilename()
        if file != '':
            #tt,ff=self.readTangraCSV(archivo=file,exp=float(self.expt2.get()),cent=int(self.cent2.get()))
            kk=np.loadtxt(file,delimiter=',',skiprows=int(self.skiprows2.get()))
            flx=kk[:,2];normflx=flx/(np.mean(flx[-20:]))#Normalize curve
            exp=float(self.expt2.get())
            cent=int(self.cent2.get())
            num=kk[:,0];num=num-cent #centering curve
            secs=exp*num
            self.draw_graphic([], [],secs,normflx,True)

aplicacion1=Aplicacion()
