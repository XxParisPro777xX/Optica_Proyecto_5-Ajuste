import matplotlib.pyplot as plt

def plot():
    fig = plt.figure(figsize=(8,8), dpi=100)
    p = fig.add_subplot(221)   #top left
    p2 =fig.add_subplot(222)   #top right
    p3 =fig.add_subplot(223, facecolor="gray")   #bottom left
    p4 =fig.add_subplot(224, facecolor="gray")   #bottom right
    return p,p2,p3,p4,fig

def display_image(img,D):
    plt.figure( )
    plt.clf()
    img= plt.imshow( img, extent = [ -D , D , -D , D  ] )
    plt.gray()
    plt.title( "title" )
    plt.xlabel( "x_label" )
    plt.ylabel( "y_label" )
    plt.show( block = "block" )
    return img
