import matplotlib.pyplot as plt
import numpy as np

def plot():
    fig = plt.figure(figsize=(8,8), dpi=100)
    p = fig.add_subplot(221)   #top left
    p2 =fig.add_subplot(222)   #top right
    p3 =fig.add_subplot(223, facecolor="gray")   #bottom left
    p4 =fig.add_subplot(224, facecolor="gray")   #bottom right
    return p,p2,p3,p4,fig

def display_image(img,D):
    plt.figure( )
    plt.clf()
    img= plt.imshow( img, extent = [ -D/2 , D/2 , -D/2 , D/2  ] )
    plt.gray()
    plt.title( "title" )
    plt.xlabel( "x_label" )
    plt.ylabel( "y_label" )
    #plt.show( block = "block" )
    plt.show( block = False )
    return img

def display_pattern(img,D,b,T):
    '''
    Function to display diffracction pattern plus readline
    img--> matrix with diffraction values
    D--> FOV in m
    b--> impact parameter in m
    T--> Angle of reading
    '''
    
    M=len(img)
    m2p=M/D
    x=np.linspace(-D/2,D/2,M)
    #calcular los arreglos de coordenada X a extraer
    x1=x*np.cos(T*np.pi/180)-b*np.sin(T*np.pi/180)
    x2=x*np.sin(T*np.pi/180)+b*np.cos(T*np.pi/180)
        
    plt.figure( )
    plt.clf()
    img= plt.imshow( img, extent = [ -D /2, D /2, -D /2, D /2 ] )
    plt.plot(x1,x2)
    plt.gray()
    plt.title( "title" )
    plt.xlabel( "x_label" )
    plt.ylabel( "y_label" )
    #plt.show( block = "block" )
    #plt.plot(block=False)
    return img
