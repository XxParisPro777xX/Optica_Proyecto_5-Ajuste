import sys
import os
sys.path.insert( 1, os.path.join( os.path.dirname( os.path.abspath( __file__ ) ), "../" ) )

import tkinter
import math
import numpy as np
import matplotlib.pyplot as plt
from PIL import Image, ImageDraw

import difraciones_lab as dif

import bezier

def rgb( r, g, b ):
    return "#%02x%02x%02x" % ( r, b, b )

class Editor ( tkinter.Canvas ):
    def __init__( self, root, canvas_size ):
        super().__init__( root, width = canvas_size, height = canvas_size, scrollregion = ( -canvas_size / 2, -canvas_size / 2, canvas_size / 2, canvas_size / 2 ), background = "white", relief = "ridge", borderwidth = 5 )
        self.root = root
        self.canvas_size = canvas_size
        self.poly_points = []
        self.canvas_curve = None
        self.selected_point = None
        self.nearest_point = None
        self.point_mark = None
        self.visible_point_mark = False
        self.curve_segments = []
        self.curve = []
        self.pr = 3
        self.r = 100
        self.initialize()
        self.create_poly()

    def initialize( self ):
        self.xview_moveto( 0 )
        self.yview_moveto( 0 )
        self.bind( "<ButtonPress-1>", self.mouse_pressed )
        self.bind( "<ButtonRelease-1>", self.mouse_released )
        self.bind( "<ButtonRelease-3>", self.remove_point )
        self.bind( "<KeyPress-Control_L>", self.show_mark )
        self.bind( "<KeyRelease-Control_L>", self.hide_mark )
        self.bind( "<Motion>", self.mouse_moved )
        self.bind( "<Control-f>", self.process_image )
        self.focus_set()
        self.pack()

    def create_poly( self, n = 10 ):
        if not self.poly_points is None:
            for p in self.poly_points:
                self.delete( p[ "point" ] )
        self.poly_points = []
        for i in range( 0, n ):
            point = {
                "x": math.cos( i * 2 * math.pi / n ) * self.r,
                "y": math.sin( i * 2 * math.pi / n ) * self.r
            }
            point[ "point" ] = self.create_oval( 0, 0, 0, 0, fill = rgb( 0, 0, 0 ) )
            self.update_point( point )
            self.poly_points.append( point )
        self.update_poly()
        self.tag_lower( self.create_polygon( self.curve, fill = "", outline = rgb( 150, 150, 150 ) ) )

    def update_poly( self ):
        self.poly = []
        for p in self.poly_points:
            self.poly.append( p[ "x" ] )
            self.poly.append( p[ "y" ] )
        if not self.canvas_curve is None:
            self.delete( self.canvas_curve )
        self.curve_segments, self.curve = bezier.kochanek_bartels_curve( np.linspace( 0, 1 ), self.poly[ 0 :: 2 ], self.poly[ 1 :: 2 ] )
        self.canvas_curve = self.create_polygon( self.curve, fill = "", outline = rgb( 0, 0, 0 ) )

    def update_point( self, point ):
        self.coords( point[ "point" ], point[ "x" ] - self.pr, point[ "y" ] - self.pr, point[ "x" ] + self.pr, point[ "y" ] + self.pr )

    def update_point_mark( self ):
        self.nearest_point = None
        mx = self.canvasx( self.root.winfo_pointerx() - self.winfo_rootx() )
        my = self.canvasy( self.root.winfo_pointery() - self.winfo_rooty() )
        for si, segment in enumerate( self.curve_segments ):
            for point in segment:
                d = math.sqrt( ( mx - point[ 0 ] ) ** 2 + ( my - point[ 1 ] ) ** 2 )
                if self.nearest_point is None or d < self.nearest_point[ "distance" ]:
                    self.nearest_point = {
                        "segment": si,
                        "distance": d,
                        "x": point[ 0 ],
                        "y": point[ 1 ]
                    }
        if self.point_mark is None:
            self.point_mark = self.create_oval( 0, 0, 0, 0, fill = "", outline = rgb( 0, 0, 0 ) )
        r = 5
        self.coords( self.point_mark, self.nearest_point[ "x" ] - r, self.nearest_point[ "y" ] - r, self.nearest_point[ "x" ] + r, self.nearest_point[ "y" ] + r )

    def mouse_pressed( self, event ):
        self.focus_set()
        if not self.nearest_point is None:
            point = {
                "point": self.create_oval( 0, 0, 0, 0, fill = rgb( 0, 0, 0 ) ),
                "x": self.nearest_point[ "x" ],
                "y": self.nearest_point[ "y" ]
            }
            self.poly_points.insert( self.nearest_point[ "segment" ] + 1, point )
            self.update_point( point )
        mx, my = self.canvasx( event.x ), self.canvasy( event.y )
        for p in self.poly_points:
            if math.sqrt( ( mx - p[ "x" ] ) ** 2 + ( my - p[ "y" ] ) ** 2 ) <= self.pr * 2:
                self.selected_point = p
                break

    def mouse_released( self, event ):
        self.selected_point = None

    def remove_point( self, event ):
        mx, my = self.canvasx( event.x ), self.canvasy( event.y )
        for i, p in enumerate( self.poly_points ):
            if math.sqrt( ( mx - p[ "x" ] ) ** 2 + ( my - p[ "y" ] ) ** 2 ) <= self.pr * 2:
                self.delete( p[ "point" ] )
                self.poly_points.pop( i )
                self.update_poly()
                break

    def mouse_moved( self, event ):
        if self.visible_point_mark:
            self.update_point_mark()
        if not self.selected_point is None:
            self.selected_point[ "x" ] = self.canvasx( event.x )
            self.selected_point[ "y" ] = self.canvasy( event.y )
            self.update_point( self.selected_point )
            self.update_poly()

    def show_mark( self, event ):
        if not self.visible_point_mark:
            self.visible_point_mark = True
            self.update_point_mark()

    def hide_mark( self, event ):
        self.visible_point_mark = False
        self.nearest_point = None
        if not self.point_mark is None:
            self.delete( self.point_mark )
            self.point_mark = None

    def process_image( self, M, mV, nEst, nLamb, d, ua,lmda,ang):
        print( "Processing image..." )
        #lamb = 600e-9
        D = dif.calc_plano( d, lmda, ua )
        z = ua
        virtual_scale = ( M * d ) / ( 2 * D * self.r )
        image = Image.new( "1", ( M, M ), 1 )
        draw = ImageDraw.Draw( image )
        draw.polygon( ( np.array( self.curve ) * virtual_scale + M / 2 ).tolist(), fill = "black" )
        img = np.asarray( image )
        #I1 = dif.fresnel( img, M, D, z, lmda )
        #U0,M,plano,z,nLmdas,lmda,ang
        I1s = dif.spectra( img, M, D, z, nLamb,lmda,ang)
        #_, radius = dif.calc_rstar( mV, nEst, ua )
        I1f = dif.promedio_PD(I1s, nEst, D, M, d )
        #snr = dif.SNR_TAOS2( params.mV )
        #I1n = dif.add_ruido( I1f, mV )
        print( "Processing image DONE!" )
        return img, I1f, D

    def process_curves( self, I1f, D, M, vE, vr, fps, mV, ua, toffset, T, b):
        
        print( "Processing curves..." )

        #snr = dif.SNR_TAOS2( params.mV )
        #I1n = dif.add_ruido( I1f, mV )
        xn, yn = dif.extraer_perfil( I1f, M, D, T, b )
        #lc, D, vr, fps, toff, vE, ua 
        _, _, x2, y2 = dif.muestreos( yn, D, vr, fps, toffset, vE, ua )
        
        return xn, yn, x2, y2