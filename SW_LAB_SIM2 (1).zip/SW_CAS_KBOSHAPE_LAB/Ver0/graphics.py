from tkinter import filedialog as fl
import tkinter as tk
from PIL import Image,ImageTk
import numpy as np
import matplotlib
from matplotlib.backends.backend_tkagg import (NavigationToolbar2Tk)
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import matplotlib.backends.backend_tkagg as tkagg
from matplotlib.figure import Figure
import matplotlib.pyplot as plt
import pandas as pd
matplotlib.use('TkAgg')
import editor
import plots
from tkinter import Frame


class Aplicacion:

    def __init__(self):
        self.ventana1=tk.Tk()
        self.ventana1.protocol( 'WM_DELETE_WINDOW', self.ventana1.quit )
        self.ventana1.title('SW-CAA-for-KBO-shapes')
        #self.ventana1.geometry('1450x800')
        self.ventana1.configure(bg='white')
        self.fullScreenState = False
        self.ventana1.attributes('-fullscreen', True)
        self.ventana1.bind("<F11>",
                         lambda event: self.ventana1.attributes("-fullscreen",
                                    not self.ventana1.attributes("-fullscreen")))
        self.ventana1.bind("<Escape>",
                         lambda event: self.ventana1.attributes("-fullscreen",
                                    False))
        '''self.imagen = self.imagen.resize((250, 250), Image.ANTIALIAS)
        self.imagen = ImageTk.PhotoImage(self.imagen)
        self.image_locate = tk.Button(self.ventana1,image =self.imagen)
        self.image_locate.grid(column=1,row=1,rowspan=2)'''
        self.n_rows =2
        self.n_columns =2
        for i in range(self.n_rows):
            self.ventana1.grid_rowconfigure(i,  weight =1)
        for i in range(self.n_columns):
            self.ventana1.grid_columnconfigure(i,  weight =1)
        #self.canvas1=tk.Canvas(self.ventana1, width=700, height=700, background="white",relief='ridge',borderwidth =5)
        self.canvas1=editor.Editor(self.ventana1,canvas_size=500)
        self.canvas1.grid(column=0,row=0,rowspan=1)
        e,e2,e3,e4,fs=plots.plot()
        self.f = fs
        self.p = e
        self.linea1c1, = self.p.plot([],[],'r-', color='red', label='Perfil real')
        self.linea2c1, = self.p.plot([],[],'r-', color='blue', label='Perfil muestreo')
        self.p.set_xlabel("Distancia [km]",fontdict={'family': 'serif',
                    'color' : 'darkblue',
                    'weight': 'bold',
                    'size': 10})
        self.p.set_ylabel("Flujo",fontdict={'family': 'serif',
                    'color' : 'darkblue',
                    'weight': 'bold',
                    'size': 10})
        self.p.set_title("Difraction profile",
          fontdict={'family': 'serif',
                    'color' : 'darkblue',
                    'weight': 'bold',
                    'size': 12})
        #self.linea3, = self.p.plot([],[],'r-', color='green', label='Perfil principal')
        #self.p.legend()
        self.p2 = e2
        self.linea1c2, = self.p2.plot([],[],'r-', color='red', label='Perfil real')
        self.linea2c2, = self.p2.plot([],[],'r-', color='blue', label='Perfil difracción')
        self.p2.set_xlabel("Tiempo [s]",fontdict={'family': 'serif',
                    'color' : 'darkblue',
                    'weight': 'bold',
                    'size': 10})
        self.p2.set_title("Sampled profile",
          fontdict={'family': 'serif',
                    'color' : 'darkblue',
                    'weight': 'bold',
                    'size': 12})

        #self.f2 = Figure(figsize=(8,4), dpi=100)
        self.c2 = e3
        self.c2.set_xlabel("Plane",fontdict={'family': 'serif',
                    'color' : 'darkblue',
                    'weight': 'bold',
                    'size': 12})
        self.c4 = e4
        self.c4.set_xlabel("Difraction patron" ,fontdict={'family': 'serif',
                    'color' : 'darkblue',
                    'weight': 'bold',
                    'size': 12})
        #self.p.set_xlabel("Distancia [km]")
      #  self.p.set_ylabel("Flujo")
        #self.style = Style()
       # self.style.configure("BW.TLabel", foreground="black", background="white")
#vsb = tk.Scrollbar(self.ventana1, orient="vertical", command=self.canvas1.yview)
#vsb.grid(row=0, column=1, sticky='ns')
#self.ventana1.configure(yscrollcommand=vsb.set)  
      

        #self.p2.legend()
        self.canvas = FigureCanvasTkAgg(self.f, self.ventana1)
        self.canvas.draw()
        self.canvas.get_tk_widget().grid(row=0,column=1, rowspan=2)



        self.toolbarFrame = Frame(master=self.ventana1)
        self.toolbarFrame.grid(row=2,column=1)
        self.toolbar = NavigationToolbar2Tk(self.canvas, self.toolbarFrame)
        #self.draw_graphic()
        self.prints()
        self.params()
        self.ventana1.mainloop()

    def boton_presion(self, evento):
        self.presionado=True


    def mover_mouse(self, evento):
        if self.presionado:
            self.canvas1.create_oval(evento.x-15,evento.y-15 ,evento.x+15, evento.y+15, width=2, fill='black')

    def boton_soltar(self,evento):
        self.presionado=False

    def action_button(self):
        print("hello")

    def new_window(self):
        newWindow = tk.Toplevel(self.ventana1)
        a = tk.Label(newWindow ,text = "Dato 1").grid(row = 0,column = 0)
        b = tk.Label(newWindow ,text = "Dato 2").grid(row = 1,column = 0)
        c = tk.Label(newWindow ,text = "Dato 3").grid(row = 2,column = 0)
        d = tk.Label(newWindow ,text = "Dato 4").grid(row = 3,column = 0)
        a1 = tk.Entry(newWindow).grid(row = 0,column = 1)
        b1 = tk.Entry(newWindow).grid(row = 1,column = 1)
        c1 = tk.Entry(newWindow).grid(row = 2,column = 1)
        d1 = tk.Entry(newWindow).grid(row = 3,column = 1)
        button_modal= tk.Button(newWindow, text="Cargar datos", command=self.cargar_datos,  width=10)
        button_modal.grid(column = 0, row = 4)

    def prints(self):
        self.M2=tk.StringVar()
        self.M2.set(512)
        self.vE2 = tk.StringVar()
        self.vE2.set(29800)
        self.vr2 = tk.StringVar()
        self.vr2.set(5000)
        self.ang2 = tk.StringVar()
        self.ang2.set(0)
        self.fps2 = tk.StringVar()
        self.fps2.set(20)
        self.mV2 = tk.StringVar()
        self.mV2.set(14)
        self.nEst2 = tk.StringVar()
        self.nEst2.set(34)
        self.nLamb2 = tk.StringVar()
        self.nLamb2.set(10)
        self.ua2 = tk.StringVar()
        self.ua2.set(40)
        self.d2 = tk.StringVar()
        self.d2.set(2000)
        self.T2 = tk.StringVar()
        self.T2.set(0)
        self.b2 = tk.StringVar()
        self.b2.set(0)
        self.toffset2 = tk.StringVar()
        self.toffset2.set(0)

    def params(self):
        #self.scrollbar = tk.Scrollbar(self.ventana1, orient=tk.HORIZONTAL)
        self.my_frame = tk.Frame(self.ventana1,width=300, height=300, bg="white")
        self.my_frame.grid(column=0,row=1)
       
       
        self.lab1 = tk.Label(self.my_frame ,text = "Mesh size:").grid(row = 0,column = 0)
        self.M = tk.Entry(self.my_frame,textvariable = self.M2,width=10, fg="black").grid(row = 0,column = 1,padx=5, pady=5)
        self.lab2 = tk.Label(self.my_frame ,text = "Earth translation speed [m/s]:").grid(row = 0,column = 2)
        self.vE = tk.Entry(self.my_frame,width=10,textvariable = self.vE2).grid(row = 0,column = 3, padx=5, pady=5)
        self.lab3 = tk.Label(self.my_frame ,text = "Object speed [m/s]:").grid(row = 1,column = 0, padx=1, pady=1)
        self.vr = tk.Entry(self.my_frame, width=10,textvariable = self.vr2).grid(row = 1,column = 1, padx=5, pady=5)
        self.lab4 = tk.Label(self.my_frame ,text = "Angle from opposition [deg]:").grid(row = 1,column = 2, padx=1, pady=1)
        self.ang = tk.Entry(self.my_frame,width=10,textvariable = self.ang2).grid(row = 1,column = 3, padx=5, pady=5)
        self.lab5 = tk.Label(self.my_frame ,text = "Fps").grid(row = 2,column = 0, padx=1, pady=1)
        self.fps = tk.Entry(self.my_frame,width=10, textvariable = self.fps2).grid(row = 2,column = 1, padx=5, pady=5)
        self.lab6 = tk.Label(self.my_frame ,text = "Apparent magnitude:").grid(row = 2,column = 2, padx=1, pady=1)
        self.mV = tk.Entry(self.my_frame,width=10,textvariable = self.mV2).grid(row = 2,column = 3, padx=5, pady=5)
        self.lab7 = tk.Label(self.my_frame ,text = "Stellar classification:").grid(row = 3,column = 0, padx=1, pady=1)
        self.nEst = tk.Entry(self.my_frame,width=10, textvariable = self.nEst2).grid(row = 3,column = 1, padx=5, pady=5)
        self.lab8 = tk.Label(self.my_frame ,text = "Number of wavelengths:").grid(row = 3,column = 2, padx=1, pady=1)
        self.nLamb = tk.Entry(self.my_frame,width=10,textvariable = self.nLamb2).grid(row = 3,column = 3, padx=5, pady=5)
        self.lab9 = tk.Label(self.my_frame ,text = "Object distance [au]:").grid(row = 4,column = 0, padx=1, pady=1)
        self.ua = tk.Entry(self.my_frame,width=10,textvariable = self.ua2).grid(row = 4,column = 1, padx=5, pady=5)
        self.lab10 = tk.Label(self.my_frame ,text = "Object diameter [m]:").grid(row = 4,column = 2, padx=1, pady=1)
        self.d = tk.Entry(self.my_frame,width=10, textvariable = self.d2).grid(row = 4,column = 3, padx=5, pady=5)
        self.lab11 = tk.Label(self.my_frame ,text = "Observation direction [deg]:").grid(row = 5,column = 0, padx=1, pady=1)
        self.T = tk.Entry(self.my_frame,width=10, textvariable = self.T2).grid(row = 5,column = 1, padx=5, pady=5)
        self.lab12 = tk.Label(self.my_frame ,text = "Impact parameter:").grid(row = 5,column = 2, padx=1, pady=1)
        self.b = tk.Entry(self.my_frame,width=10, textvariable = self.b2).grid(row = 5,column = 3, padx=5, pady=5)
        self.lab13 = tk.Label(self.my_frame ,text = "Time Offset [s]:").grid(row = 6,column = 0, padx=1, pady=1)
        self.toffset = tk.Entry(self.my_frame,width=10, textvariable = self.toffset2).grid(row = 6,column = 1, padx=5, pady=5)
        self.button = tk.Button(self.my_frame, text="Re-Do Calculation", command= self.actualizar,  width=10)
        self.button.grid(column=3,row=7, rowspan=2, padx=5, pady=10)
        self.button = tk.Button(self.my_frame, text="Load CSV datafile", command=self.cargar_datos,  width=10)
        self.button.grid(column=1,row=7, rowspan=2, padx=5, pady=10)
        self.button = tk.Button(self.my_frame, text="Reset", command=self.canvas1.create_poly,  width=10)
        self.button.grid(column=2,row=7, rowspan=2, padx=5, pady=10)

    def actualizar(self):
        x,y,x1,y1,img,I1f,D =self.canvas1.process_image(M = int(self.M2.get()), vE = float(self.vE2.get()), vr= float(self.vr2.get()), ang =float(self.ang2.get()), fps=float(self.fps2.get()), mV=float(self.mV2.get()), nEst=int(self.nEst2.get()), nLamb=int(self.nLamb2.get()), d=float(self.d2.get()), ua=float(self.ua2.get()), toffset=float(self.toffset2.get()), T=float(self.T2.get()), b =float(self.b2.get()))
        self.draw_graphic(x,y,x1,y1,False)
        self.draw_image(img,I1f,D)

    def draw_graphic(self,x,y,x1,y1,band):
        if band:
           self.linea1c1.set_data( x,y)
           self.linea1c2.set_data( x1,y1)
        else:
            self.linea2c1.set_data(x,y)
            self.linea2c2.set_data(x1,y1)

        self.p2.relim()
        self.p2.autoscale_view()
        self.p.relim()
        self.p.autoscale_view()
        self.f.canvas.draw()
        #print('creado 1')
        #np.savetxt("datos2.txt", np.array([x,y]).T, delimiter=",")
        #print('creado')
    def draw_image(self, img,I1f, D ):
        self.c4.imshow( I1f,extent = [ -D / 2000, D / 2000, -D / 2000, D / 2000 ], cmap=plt.cm.gray)
        self.c2.imshow( img,extent = [ -D / 2000, D / 2000, -D / 2000, D / 2000 ], cmap=plt.cm.gray)
        self.f.canvas.draw()


    def cargar_datos(self):
        file = fl.askopenfilename()
        if file != '':
            fil=open(file, "r", encoding="utf-8")#
            lista=fil.readlines()
            fil.close()
            dat=pd.read_csv(fil.name,sep=',',header=None)#datos en formato panda
            dat1=np.array(dat).T#datos en formato numpy
            self.draw_graphic([], [],dat1[0], dat1[1],True)

aplicacion1=Aplicacion()
