# SW-CAA-for-KBO-shapes
TAOS II Project

Members:
Keylin Ruiz A.
Diego Tames V.
